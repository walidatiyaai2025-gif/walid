# PCC Executive — Final UI Asset Manifest

Reference resolution: **1920 × 1080** for every screen.

## Frozen product principles
- Primary runtime: ChatGPT Web in PCC-owned Chrome sessions.
- API is optional and disabled by default.
- Manager + up to 5 worker slots.
- Hidden browser sessions by default; every chat can be opened on demand.
- Individual Open / Hide / Restart / Kill plus global Kill All PCC Sessions.
- Never kill personal Chrome sessions.
- Automatic staged dispatch with adaptive pacing.
- Automatic handling for slow responses, temporary limits, transient errors and partial responses.
- Duplicate-send protection, crash recovery and queue preservation.
- Loop Guard stops repeated no-progress work.
- Attention Center interrupts the operator only for genuinely unavoidable actions.
- Verified Completion is evidence-backed; 99% enters closure mode.
- GUI installer supports Next → Next → Install → Launch.
- Upgrades install over the old version while preserving data/settings/history.
- Update Center provides migration checks and rollback.

## Screen files
00_Setup_Wizard
00_Upgrade_Wizard
01_Chrome_Connection
02_Project_Selection
03_Dashboard_Overview
04_Manager_Workspace
05_Workers_Dispatch
06_Worker_Chat
07_Wave_Summary
08_Task_Board
09_Evidence_Verification
10_Loop_Guard
11_ChatGPT_Health_Recovery
12_Session_Monitor
13_Settings
14_Update_Center
15_Attention_Center
